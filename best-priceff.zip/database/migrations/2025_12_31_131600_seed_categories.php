<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up()
    {
        $now = now();
        DB::table('categories')->insert([
            ['name'=>'جوالات وإلكترونيات','slug'=>'جوالات-والكترونيات','icon'=>'📱','subs'=>json_encode(['جوال','لابتوب','تابلت','سماعات','شواحن','اكسسوارات','صيانة']),'created_at'=>$now,'updated_at'=>$now],
            ['name'=>'أجهزة كهربائية وطاقة','slug'=>'اجهزة-كهربائية-وطاقة','icon'=>'🔌','subs'=>json_encode(['ثلاجة','غسالة','شاشة تلفزيون','مولد كهرباء','نظام طاقة شمسية','بطاريات','انفيرتر','مراوح']),'created_at'=>$now,'updated_at'=>$now],
            ['name'=>'أثاث ومفروشات وخيام','slug'=>'اثاث-ومفروشات-وخيام','icon'=>'🛋️','subs'=>json_encode(['خيمة','شادر','مستلزمات خيام','كنب','غرفة نوم','فرشات','سجاد']),'created_at'=>$now,'updated_at'=>$now],
            ['name'=>'سيارات ودراجات','slug'=>'سيارات-ودراجات','icon'=>'🚗','subs'=>json_encode(['سيارة','دراجة نارية','دراجة هوائية','قطع غيار','زيوت','اكسسوارات مركبات']),'created_at'=>$now,'updated_at'=>$now],
            ['name'=>'مطاعم','slug'=>'مطاعم','icon'=>'🍽️','subs'=>json_encode(['وجبات سريعة','شاورما','مشاوي','حلويات']),'created_at'=>$now,'updated_at'=>$now],
            ['name'=>'عقارات','slug'=>'عقارات','icon'=>'🏠','subs'=>json_encode(['شقة (إيجار)','شقة (بيع)','محل تجاري','أرض','شاليه']),'created_at'=>$now,'updated_at'=>$now],
            ['name'=>'ملابس','slug'=>'ملابس','icon'=>'👕','subs'=>json_encode(['ملابس رجالية','ملابس نسائية','ملابس أطفال','أحذية وإكسسوارات']),'created_at'=>$now,'updated_at'=>$now],
            ['name'=>'خدمات إلكترونية','slug'=>'خدمات-الكترونية','icon'=>'💻','subs'=>json_encode(['استضافة ومواقع','تصميم وبرمجة تطبيقات','أدوات تسويق إلكتروني','خدمات الدفع والتحويل','صيانة أجهزة إلكترونية','اشتراكات']),'created_at'=>$now,'updated_at'=>$now],
            ['name'=>'مواد غذائية وسوبر ماركت','slug'=>'مواد-غذائية','icon'=>'🛒','subs'=>json_encode(['خضار وفواكه','منتجات ألبان','لحوم ودواجن','مواد معلبة وتجفيفات','مشروبات وسكر وحلويات']),'created_at'=>$now,'updated_at'=>$now],
            ['name'=>'مواد بناء ولوازم منزلية','slug'=>'مواد-بناء','icon'=>'🧰','subs'=>json_encode(['مواد بناء أساسية','أدوات كهربائية وسباكة','دهانات وأخشاب','أثاث منزلي وديكور','أدوات يدوية ومعدات صغيرة']),'created_at'=>$now,'updated_at'=>$now],
            ['name'=>'صيدليات ومستلزمات طبية','slug'=>'صيدليات-وطبي','icon'=>'🩺','subs'=>json_encode(['أدوية ووصفات طبية','مستلزمات طبية منزلية','مكملات غذائية وفيتامينات','مستلزمات أطفال ورضّع']),'created_at'=>$now,'updated_at'=>$now],
            ['name'=>'خدمات عامة','slug'=>'خدمات-عامة','icon'=>'🛠️','subs'=>json_encode(['صيانة كهرباء وسباكة','توصيل ونقل','تنظيف ومكافحة حشرات','تصليح أجهزة منزلية']),'created_at'=>$now,'updated_at'=>$now],
            ['name'=>'ترفيه وألعاب ورياضة','slug'=>'ترفيه-والعاب','icon'=>'🎮','subs'=>json_encode(['ألعاب فيديو','ألعاب أطفال','معدات رياضية','أنشطة ترفيهية']),'created_at'=>$now,'updated_at'=>$now],
            ['name'=>'زراعة وحيوانات','slug'=>'زراعة-وحيوانات','icon'=>'🐔','subs'=>json_encode(['حيوانات أليفة وطيور','أعلاف ومستلزمات الحيوانات','أدوات زراعة وبذور','معدات الري والأسمدة']),'created_at'=>$now,'updated_at'=>$now],
            ['name'=>'أخرى','slug'=>'اخرى','icon'=>'📦','subs'=>json_encode(['أخرى']),'created_at'=>$now,'updated_at'=>$now],
        ]);
    }

    public function down(): void
    {
        DB::table('categories')->truncate();
    }
};
