# 🔐 معلومات تسجيل الدخول للمدير

## بيانات حساب المدير الافتراضي

للدخول إلى لوحة التحكم الإدارية، استخدم البيانات التالية:

```
البريد الإلكتروني: admin@local.test
كلمة المرور: Admin@123456
```

## روابط مهمة

- **صفحة تسجيل الدخول**: http://localhost:8000/login
- **لوحة تحكم المدير**: http://localhost:8000/admin/dashboard
- **الصفحة الرئيسية**: http://localhost:8000/

## ملاحظات

1. تم إنشاء ملفات الترجمة العربية في مجلد `lang/ar/`:
   - `auth.php` - رسائل المصادقة
   - `validation.php` - رسائل التحقق من صحة البيانات
   - `passwords.php` - رسائل إعادة تعيين كلمة المرور
   - `pagination.php` - رسائل الترقيم

2. اللغة الافتراضية للتطبيق هي العربية (ar)

3. في حال نسيان كلمة المرور، يمكن تغييرها من خلال:
   ```bash
   php artisan tinker
   ```
   ثم تنفيذ:
   ```php
   $user = \App\Models\User::where('email', 'admin@local.test')->first();
   $user->password = bcrypt('كلمة_المرور_الجديدة');
   $user->save();
   ```

4. لتغيير كلمة المرور الافتراضية للمدير، أضف المتغير التالي في ملف `.env`:
   ```
   ADMIN_DEFAULT_PASSWORD=كلمة_المرور_الجديدة
   ```
   ثم قم بتشغيل:
   ```bash
   php artisan migrate:fresh --seed
   ```

## أنواع الحسابات

يدعم النظام ثلاثة أنواع من المستخدمين:

1. **admin** - المدير (الوصول الكامل)
2. **shop_owner** - صاحب متجر
3. **customer** - عميل عادي

## استكشاف الأخطاء

إذا واجهت مشكلة في تسجيل الدخول:

1. تأكد من تشغيل السيرفر:
   ```bash
   php artisan serve
   ```

2. امسح الكاش:
   ```bash
   php artisan config:clear
   php artisan cache:clear
   php artisan view:clear
   ```

3. تحقق من وجود المستخدم في قاعدة البيانات:
   ```bash
   php artisan tinker
   ```
   ```php
   \App\Models\User::where('email', 'admin@local.test')->first();
   ```