<div class="min-h-screen bg-gradient-to-b from-gray-50 to-white py-10" dir="rtl" x-cloak>
  <div class="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="bg-white shadow-xl rounded-3xl overflow-hidden border border-gray-100">
      <div class="p-6 sm:p-8 bg-gradient-to-r from-red-600 to-orange-500 text-white">
        <div class="flex items-center justify-between gap-4">
          <div>
            <h1 class="text-2xl sm:text-3xl font-black">إضافة سعر جديد</h1>
            <p class="text-white/90 text-sm mt-1">اختر القسم ثم النوع ثم (الشركة) ثم الموديل، وبعدها أكمل السعر وباقي البيانات</p>
          </div>
          <div class="text-4xl">🏷️</div>
        </div>
      </div>

      <div class="p-6 sm:p-8">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
          <div class="mb-6 bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded-xl">
            <?php echo e(session('success')); ?>

          </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->any()): ?>
          <div class="mb-6 bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-xl">
            <div class="font-bold mb-2">يرجى تصحيح الأخطاء التالية:</div>
            <ul class="list-disc list-inside text-sm space-y-1">
              <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </ul>
          </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <form wire:submit.prevent="store" class="space-y-6">

          
          <div class="bg-blue-50 border border-blue-200 rounded-xl p-4 text-center">
            <p class="text-sm font-bold text-blue-800">
              <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$category): ?>
                👉 ابدأ باختيار القسم أولاً
              <?php elseif(!$sub_category): ?>
                👉 اختر نوع المنتج من القسم <span class="text-red-600"><?php echo e($category); ?></span>
              <?php elseif($categoryType === 'service_text' && !$name): ?>
                👉 أدخل وصف الخدمة أو المنتج
              <?php elseif($categoryType === 'brand_model' && $showBrandField && !$brand): ?>
                👉 اختر الشركة المصنعة أو أدخلها يدوياً
              <?php elseif($categoryType !== 'service_text' && !$name): ?>
                👉 اختر <?php echo e($categoryType === 'brand_model' ? 'الموديل' : 'المواصفات'); ?> من القائمة أو أدخله يدوياً
              <?php else: ?>
                ✨ رائع! الآن أكمل السعر وبيانات المحل
              <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </p>
          </div>

          <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($categoryType !== 'service_text'): ?>
          <div class="grid grid-cols-4 gap-2 text-center text-xs font-bold mb-6">
            <div class="p-3 rounded-xl transition-all <?php echo e($category ? 'bg-green-100 text-green-800 shadow-sm border-2 border-green-300' : 'bg-gray-100 text-gray-500'); ?>">
              <div class="text-lg mb-1"><?php echo e($category ? '✅' : '1️⃣'); ?></div>
              <div>القسم</div>
            </div>
            <div class="p-3 rounded-xl transition-all <?php echo e($sub_category ? 'bg-green-100 text-green-800 shadow-sm border-2 border-green-300' : 'bg-gray-100 text-gray-500'); ?>">
              <div class="text-lg mb-1"><?php echo e($sub_category ? '✅' : '2️⃣'); ?></div>
              <div>النوع</div>
            </div>
            <div class="p-3 rounded-xl transition-all <?php echo e((!$showBrandField || $brand) ? 'bg-green-100 text-green-800 shadow-sm border-2 border-green-300' : 'bg-gray-100 text-gray-500'); ?>">
              <div class="text-lg mb-1"><?php echo e((!$showBrandField || $brand) ? '✅' : '3️⃣'); ?></div>
              <div><?php echo e($showBrandField ? 'الشركة' : 'تلقائي'); ?></div>
            </div>
            <div class="p-3 rounded-xl transition-all <?php echo e($name ? 'bg-green-100 text-green-800 shadow-sm border-2 border-green-300' : 'bg-gray-100 text-gray-500'); ?>">
              <div class="text-lg mb-1"><?php echo e($name ? '✅' : '4️⃣'); ?></div>
              <div><?php echo e($categoryType === 'brand_model' ? 'الموديل' : 'المواصفات'); ?></div>
            </div>
          </div>
          <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

          <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label class="block text-gray-800 text-sm font-bold mb-2">القسم</label>
              <select wire:model.live="category" class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-red-500 bg-white">
                <option value="">-- اختر القسم --</option>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $categoriesList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($cat['name']); ?>"><?php echo e($cat['icon'] ?? '📦'); ?> <?php echo e($cat['name']); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
              </select>
              <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-xs text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

            <div>
              <label class="block text-gray-800 text-sm font-bold mb-2">نوع المنتج</label>
              <select wire:model.live="sub_category" class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-red-500 bg-white" <?php echo e($category ? '' : 'disabled'); ?>>
                <option value="">-- اختر النوع --</option>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $this->getSubCategoriesProperty(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($sub); ?>"><?php echo e($sub); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
              </select>
              <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['sub_category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-xs text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
          </div>

          
          <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($categoryType === 'service_text'): ?>
            
            <div>
              <label class="block text-gray-800 text-sm font-bold mb-2">وصف الخدمة أو المنتج</label>
              <input type="text" 
                     wire:model.live="name"
                     placeholder="<?php echo e($serviceTextPlaceholder); ?>" 
                     class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-red-500"
                     <?php echo e(($category && $sub_category) ? '' : 'disabled'); ?>>
              <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-xs text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
          <?php elseif($categoryType === 'variant_specs' && !empty($variantSpecs)): ?>
            
            <div class="space-y-4">
              <div class="bg-amber-50 border border-amber-200 rounded-xl p-3 text-center">
                <p class="text-sm font-bold text-amber-800">
                  📋 املأ جميع المواصفات المطلوبة
                </p>
              </div>
              
              <div class="grid grid-cols-1 sm:grid-cols-<?php echo e(min(count($variantSpecs), 3)); ?> gap-4">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $variantSpecs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $spec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="<?php echo e(count($variantSpecs) > 3 && $index >= 3 ? 'sm:col-span-' . min(count($variantSpecs), 3) : ''); ?>">
                    <label class="block text-gray-800 text-sm font-bold mb-2">
                      <?php echo e($spec['name']); ?> 
                      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($spec['required']) && $spec['required']): ?>
                        <span class="text-red-600">*</span>
                      <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </label>
                    
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($spec['type'] === 'select'): ?>
                      
                      <select wire:model.live="spec<?php echo e($index + 1); ?>"
                              class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-red-500 bg-white" 
                              <?php echo e(($category && $sub_category) ? '' : 'disabled'); ?>>
                        <option value="">-- اختر <?php echo e($spec['name']); ?> --</option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $spec['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($option); ?>"><?php echo e($option); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                      </select>
                    <?php elseif($spec['type'] === 'number'): ?>
                      
                      <input type="number" 
                             wire:model.live="spec<?php echo e($index + 1); ?>"
                             placeholder="<?php echo e($spec['placeholder'] ?? ''); ?>"
                             class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-red-500"
                             <?php echo e(($category && $sub_category) ? '' : 'disabled'); ?>>
                    <?php else: ?>
                      
                      <input type="text" 
                             wire:model.live="spec<?php echo e($index + 1); ?>"
                             placeholder="<?php echo e($spec['placeholder'] ?? ''); ?>"
                             class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-red-500"
                             <?php echo e(($category && $sub_category) ? '' : 'disabled'); ?>>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['spec' . ($index + 1)];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-xs text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
              </div>
              
              <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($name): ?>
                <div class="bg-green-50 border border-green-200 rounded-xl p-3 text-center">
                  <p class="text-xs text-green-700 font-bold">المواصفات المختارة:</p>
                  <p class="text-sm font-black text-green-800 mt-1"><?php echo e($name); ?></p>
                </div>
              <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
          <?php else: ?>
            
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
              
              <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($showBrandField): ?>
                <div>
                  <div class="flex items-center justify-between">
                    <label class="block text-gray-800 text-sm font-bold mb-2">الشركة</label>
                  </div>

                  <select wire:model.live="brand"
                          class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-red-500 bg-white" 
                          <?php echo e(($category && $sub_category) ? '' : 'disabled'); ?>>
                    <option value="">-- اختر الشركة (<?php echo e(count($brands)); ?> خيار) --</option>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($brands)): ?>
                      <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($b); ?>"><?php echo e($b); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                      <option value="__custom__">✍️ أخرى (إدخال يدوي)</option>
                    <?php else: ?>
                      <option value="" disabled>لا توجد شركات متاحة</option>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                  </select>
                  
                  <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($brand === '__custom__'): ?>
                    <div class="mt-2">
                      <input type="text" 
                             wire:model.live="brand"
                             placeholder="اكتب اسم الشركة ثم اضغط Enter" 
                             class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-red-500"
                             autofocus>
                    </div>
                  <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                  <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['brand'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-xs text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
              <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

              
              <div class="<?php echo e($showBrandField ? '' : 'col-span-2'); ?>">
                <label class="block text-gray-800 text-sm font-bold mb-2">
                  <?php echo e($categoryType === 'brand_model' ? 'الموديل / اسم المنتج' : 'المواصفات'); ?>

                </label>
                
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($models)): ?>
                  <select wire:model.live="name"
                          class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-red-500 bg-white" 
                          <?php echo e(($category && $sub_category && (!$showBrandField || ($brand && $brand !== '__custom__'))) ? '' : 'disabled'); ?>>
                    <option value="">-- <?php echo e($categoryType === 'brand_model' ? 'اختر الموديل' : 'اختر المواصفات'); ?> (<?php echo e(count($models)); ?> خيار) --</option>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($m); ?>"><?php echo e($m); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <option value="__custom__">✍️ إدخال يدوي</option>
                  </select>
                  
                  <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($name === '__custom__'): ?>
                    <div class="mt-2">
                      <input type="text" 
                             wire:model.live="name"
                             placeholder="<?php echo e($categoryType === 'brand_model' ? 'اكتب اسم الموديل (مثل: iPhone 15 Pro Max)' : 'اكتب المواصفات'); ?>" 
                             class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-red-500"
                             autofocus>
                    </div>
                  <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php else: ?>
                  <input type="text" 
                         wire:model.live="name"
                         placeholder="<?php echo e($categoryType === 'brand_model' ? 'اكتب اسم الموديل (مثل: iPhone 15 Pro Max)' : 'اكتب المواصفات'); ?>" 
                         class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-red-500"
                         <?php echo e(($category && $sub_category && (!$showBrandField || ($brand && $brand !== '__custom__'))) ? '' : 'disabled'); ?>>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-xs text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
              </div>
            </div>
          <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

          <div class="grid grid-cols-1 sm:grid-cols-<?php echo e($showConditionField ? '2' : '1'); ?> gap-4">
            <div>
              <label class="block text-gray-800 text-sm font-bold mb-2">السعر (شيكل)</label>
              <div class="relative">
                <input type="number" step="0.01" wire:model="price" placeholder="0.00"
                       class="w-full px-4 py-3 border border-green-200 rounded-xl focus:ring-2 focus:ring-green-500 bg-green-50 font-black text-lg text-green-800" />
                <span class="absolute left-4 top-3.5 text-green-700 font-bold">₪</span>
              </div>
              <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-xs text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($showConditionField): ?>
              <div>
                <label class="block text-gray-800 text-sm font-bold mb-2">حالة المنتج</label>
                <div class="grid grid-cols-2 gap-2">
                  <button type="button" 
                          wire:click="$set('condition', 'new')"
                          class="flex items-center justify-center gap-2 border rounded-xl py-3 cursor-pointer transition <?php echo e($condition === 'new' ? 'border-red-500 bg-red-50 shadow-sm' : 'border-gray-200 bg-white hover:border-red-200'); ?>">
                    <span>🆕</span><span class="font-bold">جديد</span>
                  </button>
                  <button type="button" 
                          wire:click="$set('condition', 'used')"
                          class="flex items-center justify-center gap-2 border rounded-xl py-3 cursor-pointer transition <?php echo e($condition === 'used' ? 'border-red-500 bg-red-50 shadow-sm' : 'border-gray-200 bg-white hover:border-red-200'); ?>">
                    <span>♻️</span><span class="font-bold">مستعمل</span>
                  </button>
                </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['condition'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-xs text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
              </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label class="block text-gray-800 text-sm font-bold mb-2">المنطقة</label>
              <select wire:model="city" class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 bg-white">
                <option value="">اختر..</option>
                <option value="شمال غزة">شمال غزة</option>
                <option value="مدينة غزة">مدينة غزة</option>
                <option value="المنطقة الوسطى">المنطقة الوسطى</option>
                <option value="خانيونس">خانيونس</option>
                <option value="رفح">رفح</option>
              </select>
              <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-xs text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!auth()->check() || !auth()->user()->isShopOwner() || !auth()->user()->is_approved): ?>
            <div>
              <label class="block text-gray-800 text-sm font-bold mb-2">اسم المحل</label>
              <input type="text" wire:model="shop_name" placeholder="مثلاً: معرض القدس"
                     class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500" />
              <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['shop_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-xs text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
            <?php else: ?>
            <div>
              <label class="block text-gray-800 text-sm font-bold mb-2">اسم المحل</label>
              <input type="text" value="<?php echo e(auth()->user()->shop_name); ?>" disabled
                     class="w-full px-4 py-3 border border-gray-200 rounded-xl bg-gray-100 text-gray-700 font-bold cursor-not-allowed" />
              <p class="text-xs text-gray-500 mt-1">يتم استخدام اسم متجرك تلقائياً</p>
            </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label class="block text-gray-800 text-sm font-bold mb-2">رقم التواصل / واتساب (اختياري)</label>
              <input type="text" wire:model="contact_phone" placeholder="059xxxxxxx"
                     class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500" />
              <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['contact_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-xs text-red-600 mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
            <div>
              <label class="block text-gray-800 text-sm font-bold mb-2">تفاصيل العنوان (اختياري)</label>
              <input type="text" wire:model="address_details" placeholder="الشارع، المعلم القريب..."
                     class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500" />
            </div>
          </div>

          <div>
            <label class="block text-gray-800 text-sm font-bold mb-2">صورة المنتج (اختياري)</label>
            <div class="flex items-center justify-center w-full">
              <label class="flex flex-col items-center justify-center w-full h-40 border-2 border-dashed rounded-2xl cursor-pointer bg-gray-50 hover:bg-gray-100 transition relative overflow-hidden border-gray-200">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($image): ?>
                  <img src="<?php echo e($image->temporaryUrl()); ?>" class="absolute inset-0 w-full h-full object-cover opacity-90" alt="preview" />
                  <div class="z-10 bg-white/90 px-3 py-1 rounded-xl text-xs font-bold text-green-700">تم اختيار الصورة ✅</div>
                <?php else: ?>
                  <div class="flex flex-col items-center justify-center">
                    <div class="text-3xl mb-2">🖼️</div>
                    <p class="text-sm font-bold text-gray-700">اضغط لرفع صورة</p>
                    <p class="text-xs text-gray-500">jpeg/png/webp حتى 5MB</p>
                  </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <input type="file" wire:model="image" class="hidden" accept="image/*" />
              </label>
            </div>
            <div wire:loading wire:target="image" class="text-xs text-blue-600 mt-2 font-bold">جاري رفع الصورة...</div>
          </div>

          <input type="hidden" wire:model="added_by" />

          <div class="pt-2">
            <button type="submit" class="w-full bg-gradient-to-r from-red-600 to-orange-500 hover:from-red-700 hover:to-orange-600 text-white font-black py-4 px-4 rounded-2xl shadow-lg transition transform hover:scale-[1.01] flex justify-center items-center gap-3">
              <span>نشر السعر الآن</span>
              <span wire:loading class="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full"></span>
            </button>
            <a href="<?php echo e(route('home')); ?>" class="block text-center mt-4 text-gray-500 text-sm hover:text-red-600 transition">إلغاء وعودة للرئيسية</a>
          </div>

        </form>
      </div>
    </div>
  </div>
</div><?php /**PATH /home/mohnd/projects/last/best-price/resources/views/livewire/create-product.blade.php ENDPATH**/ ?>