<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            مقارنة الأسعار - {{ $subCategory }}
        </h2>
    </x-slot>

    <div class="py-8">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <!-- العودة للأقسام -->
            <div class="mb-6">
                <a href="{{ route('home') }}" class="inline-flex items-center gap-2 text-red-600 hover:text-red-700 font-medium">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
                    </svg>
                    العودة للأقسام
                </a>
            </div>

            <!-- العنوان -->
            <div class="text-center mb-8">
                <h1 class="text-3xl font-black text-gray-800 mb-2">
                    🏆 أفضل أسعار {{ $subCategory }}
                </h1>
                <p class="text-gray-600">
                    أرخص سعر لكل موديل من {{ $category }}
                </p>
            </div>

            @if(empty($bestPrices))
                <div class="text-center py-16">
                    <div class="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center text-4xl mx-auto mb-4 grayscale opacity-50">📦</div>
                    <h3 class="text-lg font-bold text-gray-600 mb-2">لا توجد منتجات</h3>
                    <p class="text-gray-400">لم يتم العثور على أي منتجات في هذا القسم</p>
                </div>
            @else
                <!-- جدول المقارنة -->
                <div class="bg-white rounded-xl shadow-lg overflow-hidden">
                    <div class="bg-gradient-to-r from-red-600 to-red-700 text-white px-6 py-4">
                        <h3 class="text-lg font-bold flex items-center gap-2">
                            <span>🏷️</span>
                            أفضل الأسعار المتاحة
                        </h3>
                    </div>
                    
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">الموديل</th>
                                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">أفضل سعر</th>
                                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">المحل</th>
                                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">المدينة</th>
                                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">المصدر</th>
                                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">كود العرض</th>
                                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">التاريخ</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                @foreach($bestPrices as $index => $product)
                                    <tr class="hover:bg-gray-50 transition {{ $index === 0 ? 'bg-green-50' : '' }}">
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="flex items-center gap-2">
                                                @if($index === 0)
                                                    <span class="bg-yellow-400 text-white text-xs px-2 py-1 rounded-full font-bold">🥇 الأفضل</span>
                                                @endif
                                                <a href="{{ route('products.show', $product['id']) }}" 
                                                   class="font-medium text-gray-900 hover:text-red-600 hover:underline transition">
                                                    {{ $product['model'] }}
                                                </a>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <span class="text-xl font-black text-red-600">
                                                {{ number_format($product['best_price'], 2) }} ₪
                                            </span>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                            {{ $product['shop_name'] }}
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                            {{ $product['city'] }}
                                        </td>
                                         <td class="px-6 py-4 whitespace-nowrap">
                                             @if($product['added_by'] == 'shop_owner' && isset($product['user']) && $product['user'] && $product['user']->is_approved)
                                                 {{-- متجر معتمد --}}
                                                 <a href="{{ route('shop.show', ['id' => $product['user_id']]) }}" 
                                                    class="inline-flex items-center gap-1 bg-purple-600 hover:bg-purple-700 text-white text-xs px-3 py-1.5 rounded-lg transition font-bold">
                                                     <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                         <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"></path>
                                                     </svg>
                                                     متجر معتمد
                                                 </a>
                                             @else
                                                 {{-- زبون / مواطن --}}
                                                 <span class="inline-flex items-center gap-1 bg-green-600 text-white text-xs px-3 py-1.5 rounded-lg font-bold">
                                                     <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                         <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                                                     </svg>
                                                     زبون
                                                 </span>
                                             @endif
                                         </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <a href="{{ route('products.show', $product['id']) }}" 
                                               class="font-bold text-blue-600 bg-blue-50 hover:bg-blue-100 px-2 py-1 rounded text-xs inline-block transition">
                                                {{ $product['reference_code'] }}
                                            </a>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            {{ $product['created_at']->format('Y-m-d') }}
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- ملخص إحصائي -->
                <div class="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div class="bg-gradient-to-br from-green-50 to-green-100 p-6 rounded-xl border border-green-200">
                        <div class="text-3xl font-bold text-green-700 mb-2">
                            {{ number_format($bestPrices[0]['best_price'], 2) }} ₪
                        </div>
                        <div class="text-sm text-green-600 font-medium">أرخص سعر</div>
                        <div class="text-xs text-green-500 mt-1">{{ $bestPrices[0]['model'] }}</div>
                    </div>
                    
                    <div class="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-xl border border-blue-200">
                        <div class="text-3xl font-bold text-blue-700 mb-2">{{ count($bestPrices) }}</div>
                        <div class="text-sm text-blue-600 font-medium">إجمالي الموديلات</div>
                        <div class="text-xs text-blue-500 mt-1">{{ $subCategory }}</div>
                    </div>
                    
                    <div class="bg-gradient-to-br from-purple-50 to-purple-100 p-6 rounded-xl border border-purple-200">
                        <div class="text-3xl font-bold text-purple-700 mb-2">
                            {{ number_format(array_sum(array_column($bestPrices, 'best_price')) / count($bestPrices), 2) }} ₪
                        </div>
                        <div class="text-sm text-purple-600 font-medium">متوسط السعر</div>
                        <div class="text-xs text-purple-500 mt-1">للموديل</div>
                    </div>
                </div>
            @endif
        </div>
    </div>
</x-app-layout>
