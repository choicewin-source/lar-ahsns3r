<x-app-layout>
    <livewire:product-details :id="$product->id" />
</x-app-layout>