# دليل اختبار تسجيل المتجر 🏪

## نظرة عامة
هذا الدليل يشرح كيفية التحقق من أن نظام تسجيل المتاجر يعمل بشكل صحيح، بما في ذلك:
- ✅ تسجيل المتجر عبر النموذج التقليدي
- ✅ تسجيل المتجر عبر حساب Google
- ✅ إرسال رسائل البريد الإلكتروني للمديرين
- ✅ إرسال رسالة تأكيد البريد الإلكتروني للمستخدم

---

## المتطلبات الأولية

### 1. التحقق من إعدادات Google OAuth

تأكد من أن الملف `.env` يحتوي على:

```env
GOOGLE_CLIENT_ID=57158123082-enckaf1upp8f58q8cttmi54fec49597o.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=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
GOOGLE_REDIRECT_URL=http://localhost:8000/auth/google/callback
```

⚠️ **مهم**: تأكد من أن `GOOGLE_REDIRECT_URL` يطابق URL الذي يعمل عليه التطبيق.

### 2. تشغيل Migrations

```bash
php artisan migrate
```

تأكد من أن جدول `users` يحتوي على الحقول التالية:
- `google_id` (nullable)
- `avatar` (nullable)
- `shop_name` (nullable)
- `shop_city` (nullable)
- `shop_phone` (nullable)
- `is_approved` (boolean, default: false)
- `email_verified_at` (timestamp, nullable)

---

## طرق اختبار إرسال البريد الإلكتروني

### الطريقة 1: استخدام Log Driver (للتطوير)

في ملف `.env`:
```env
MAIL_MAILER=log
```

**كيفية التحقق:**
1. افتح الملف: `storage/logs/laravel.log`
2. بعد تسجيل متجر جديد، ستجد رسالة البريد في اللوق
3. ابحث عن "طلب تسجيل متجر جديد"

---

### الطريقة 2: استخدام Mailtrap (موصى بها للتطوير)

**الخطوات:**

1. **إنشاء حساب مجاني على Mailtrap:**
   - زر الموقع: https://mailtrap.io
   - سجل حساب مجاني
   - انتقل إلى "Email Testing" > "Inboxes"
   - انشئ Inbox جديد أو استخدم الافتراضي

2. **احصل على بيانات SMTP:**
   - اضغط على Inbox
   - اختر تبويب "SMTP Settings"
   - اختر "Laravel 9+" من القائمة المنسدلة
   - انسخ الإعدادات

3. **حدّث ملف `.env`:**
```env
MAIL_MAILER=smtp
MAIL_HOST=sandbox.smtp.mailtrap.io
MAIL_PORT=2525
MAIL_USERNAME=your_mailtrap_username
MAIL_PASSWORD=your_mailtrap_password
MAIL_ENCRYPTION=tls
MAIL_FROM_ADDRESS="info@ahsansanar.com"
MAIL_FROM_NAME="أحسن سعر"
```

4. **امسح الكاش:**
```bash
php artisan config:clear
php artisan cache:clear
```

**كيفية التحقق:**
- بعد تسجيل متجر، افتح Mailtrap Inbox
- ستظهر الرسالة فوراً
- يمكنك فتحها وقراءة محتواها

---

### الطريقة 3: استخدام Gmail (للإنتاج)

⚠️ **تحذير**: هذه الطريقة للإنتاج فقط، استخدم Mailtrap للتطوير

1. **إنشاء App Password في Gmail:**
   - اذهب إلى: https://myaccount.google.com/security
   - فعّل "2-Step Verification" إذا لم يكن مفعلاً
   - ابحث عن "App passwords"
   - أنشئ App Password جديد واحفظه

2. **حدّث ملف `.env`:**
```env
MAIL_MAILER=smtp
MAIL_HOST=smtp.gmail.com
MAIL_PORT=587
MAIL_USERNAME=your_email@gmail.com
MAIL_PASSWORD=your_app_password
MAIL_ENCRYPTION=tls
MAIL_FROM_ADDRESS="your_email@gmail.com"
MAIL_FROM_NAME="أحسن سعر"
```

---

## سيناريوهات الاختبار

### السيناريو 1: تسجيل متجر عبر النموذج التقليدي ✅

**الخطوات:**

1. افتح المتصفح واذهب إلى: `http://localhost:8000/register-shop`

2. املأ النموذج بالبيانات التالية:
   - **الاسم الشخصي**: أحمد محمد
   - **اسم المتجر**: معرض النور للإلكترونيات
   - **المدينة**: مدينة غزة
   - **رقم الهاتف**: 0591234567
   - **البريد الإلكتروني**: test-shop@example.com
   - **كلمة المرور**: Password123!
   - **تأكيد كلمة المرور**: Password123!

3. اضغط على زر "تسجيل المتجر"

**النتيجة المتوقعة:**
- ✅ يتم تحويلك إلى صفحة "طلبك قيد المراجعة" (`/register-pending`)
- ✅ تظهر رسالة نجاح: "تم تسجيل متجرك بنجاح!"
- ✅ تظهر معلومات المتجر المسجل
- ✅ يتم إرسال بريد إلكتروني للمديرين

**التحقق من البريد الإلكتروني:**
- افتح Mailtrap أو `storage/logs/laravel.log`
- ابحث عن رسالة "طلب تسجيل متجر جديد"
- تحقق من وجود معلومات المتجر في الرسالة

**التحقق من قاعدة البيانات:**
```bash
php artisan tinker
```
```php
$user = \App\Models\User::where('email', 'test-shop@example.com')->first();
echo "Name: " . $user->name . "\n";
echo "Shop Name: " . $user->shop_name . "\n";
echo "Role: " . $user->role . "\n";
echo "Is Approved: " . ($user->is_approved ? 'Yes' : 'No') . "\n";
echo "Email Verified: " . ($user->email_verified_at ? 'Yes' : 'No') . "\n";
```

**النتيجة المتوقعة في قاعدة البيانات:**
```
Name: أحمد محمد
Shop Name: معرض النور للإلكترونيات
Role: shop_owner
Is Approved: No
Email Verified: No
```

---

### السيناريو 2: تسجيل متجر عبر Google ✅

**الخطوات:**

1. افتح المتصفح واذهب إلى: `http://localhost:8000/register-shop`

2. اضغط على زر "تسجيل المتجر باستخدام Google"

3. سيتم تحويلك إلى صفحة Google للمصادقة

4. سجل الدخول بحساب Google الخاص بك

5. وافق على الأذونات المطلوبة

6. سيتم تحويلك إلى صفحة "أكمل تسجيل متجرك"

7. املأ المعلومات المطلوبة:
   - **اسم المتجر**: معرض التكنولوجيا الحديثة
   - **المدينة**: خانيونس
   - **رقم الهاتف**: 0599876543

8. اضغط على "إكمال تسجيل المتجر"

**النتيجة المتوقعة:**
- ✅ يتم تحويلك إلى صفحة "طلبك قيد المراجعة"
- ✅ تظهر صورة حسابك من Google
- ✅ يتم إرسال بريد إلكتروني للمديرين

**التحقق من قاعدة البيانات:**
```php
$user = \App\Models\User::where('shop_name', 'معرض التكنولوجيا الحديثة')->first();
echo "Google ID: " . ($user->google_id ? 'Found' : 'Not Found') . "\n";
echo "Avatar: " . ($user->avatar ? 'Found' : 'Not Found') . "\n";
echo "Email Verified: " . ($user->email_verified_at ? 'Yes' : 'No') . "\n";
```

**النتيجة المتوقعة:**
```
Google ID: Found
Avatar: Found
Email Verified: Yes  (لأن Google يؤكد البريد تلقائياً)
```

---

### السيناريو 3: التحقق من تأكيد البريد الإلكتروني ✉️

**ملاحظة**: Laravel Breeze يرسل رسالة تأكيد البريد تلقائياً عند التسجيل

**الخطوات:**

1. بعد تسجيل متجر عبر النموذج التقليدي
2. افتح Mailtrap أو `storage/logs/laravel.log`
3. ستجد رسالتين:
   - **للمدير**: "طلب تسجيل متجر جديد"
   - **للمستخدم**: "Verify Email Address"

**التحقق من رسالة التأكيد:**
- افتح الرسالة الموجهة للمستخدم
- يجب أن تحتوي على زر "Verify Email Address"
- الرابط يجب أن يكون بالشكل: `http://localhost:8000/verify-email/ID/HASH`

**اختبار التأكيد:**
1. انسخ رابط التأكيد من البريد
2. افتحه في المتصفح
3. يجب أن تظهر رسالة "Email Verified Successfully"

**التحقق من قاعدة البيانات:**
```php
$user = \App\Models\User::where('email', 'test-shop@example.com')->first();
echo "Email Verified At: " . $user->email_verified_at . "\n";
```

---

### السيناريو 4: التحقق من إشعار المديرين 📧

**الخطوات:**

1. تأكد من وجود مستخدم بدور Admin في قاعدة البيانات:
```bash
php artisan tinker
```
```php
$admin = \App\Models\User::where('role', 'admin')->first();
if (!$admin) {
    $admin = \App\Models\User::create([
        'name' => 'المدير العام',
        'email' => 'admin@ahsansanar.com',
        'password' => bcrypt('Admin123!'),
        'role' => 'admin',
        'is_approved' => true,
        'email_verified_at' => now(),
    ]);
    echo "Admin created!\n";
} else {
    echo "Admin exists: " . $admin->email . "\n";
}
```

2. سجل متجر جديد

3. افتح Mailtrap أو Laravel Log

**النتيجة المتوقعة:**
- ✅ رسالة إلى بريد المدير تحتوي على:
  - اسم المتجر
  - المدينة
  - رقم الهاتف
  - زر "مراجعة الطلب" يؤدي إلى `/admin/dashboard`

**التحقق من قاعدة البيانات:**
```php
$admin = \App\Models\User::where('role', 'admin')->first();
$notifications = $admin->notifications;
echo "Notifications count: " . $notifications->count() . "\n";
foreach ($notifications as $notification) {
    print_r($notification->data);
}
```

---

## الأخطاء الشائعة وحلولها

### 1. الخطأ: "Google OAuth not configured"

**الحل:**
```bash
# تأكد من أن config/services.php يحتوي على إعدادات Google
php artisan config:clear
php artisan cache:clear
```

---

### 2. الخطأ: "Class 'Socialite' not found"

**الحل:**
```bash
composer require laravel/socialite
```

---

### 3. الخطأ: "SQLSTATE[23000]: Integrity constraint violation"

**السبب**: عمود `google_id` غير موجود

**الحل:**
```bash
php artisan migrate:fresh
# أو
php artisan migrate:rollback
php artisan migrate
```

---

### 4. البريد الإلكتروني لا يُرسل

**الحل:**
```bash
# 1. تحقق من إعدادات .env
cat .env | grep MAIL

# 2. امسح الكاش
php artisan config:clear
php artisan cache:clear

# 3. تأكد من تشغيل Queue worker إذا كنت تستخدم queue
php artisan queue:work

# 4. افحص اللوق
tail -f storage/logs/laravel.log
```

---

### 5. الخطأ: "The redirect URI provided does not match"

**السبب**: `GOOGLE_REDIRECT_URL` في `.env` لا يطابق Google Console

**الحل:**
1. اذهب إلى: https://console.cloud.google.com/
2. اختر المشروع
3. APIs & Services > Credentials
4. اضغط على OAuth 2.0 Client ID
5. أضف `http://localhost:8000/auth/google/callback` في Authorized redirect URIs

---

## اختبار شامل (Checklist) ✅

قبل الإنتاج، تأكد من:

- [ ] تسجيل متجر عبر النموذج يعمل
- [ ] تسجيل متجر عبر Google يعمل
- [ ] إرسال بريد للمديرين يعمل
- [ ] إرسال بريد تأكيد للمستخدم يعمل
- [ ] صفحة "طلبك قيد المراجعة" تظهر بشكل صحيح
- [ ] المتجر يظهر في قاعدة البيانات بـ `is_approved = false`
- [ ] المتجر يظهر في قاعدة البيانات بـ `role = shop_owner`
- [ ] Google ID يتم حفظه بشكل صحيح
- [ ] صورة Google Avatar تُحفظ بشكل صحيح
- [ ] التحقق من البريد الإلكتروني يعمل
- [ ] التحويل التلقائي بين الصفحات يعمل
- [ ] رسائل الخطأ تظهر بشكل صحيح

---

## أوامر مفيدة للاختبار

```bash
# عرض جميع المتاجر المسجلة
php artisan tinker
\App\Models\User::where('role', 'shop_owner')->get(['id', 'name', 'shop_name', 'email', 'is_approved']);

# حذف متجر تجريبي
\App\Models\User::where('email', 'test-shop@example.com')->delete();

# الموافقة على متجر يدوياً
$shop = \App\Models\User::where('email', 'test-shop@example.com')->first();
$shop->is_approved = true;
$shop->save();

# عرض جميع الإشعارات للمدير
$admin = \App\Models\User::where('role', 'admin')->first();
$admin->notifications;

# مسح جميع الإشعارات
$admin->notifications()->delete();

# تشغيل Queue worker (إذا كنت تستخدم queue للبريد)
php artisan queue:work

# مراقبة اللوق مباشرة
tail -f storage/logs/laravel.log
```

---

## خلاصة

الآن يمكنك اختبار:
1. ✅ تسجيل متجر عبر النموذج التقليدي
2. ✅ تسجيل متجر عبر Google OAuth
3. ✅ إرسال رسائل البريد الإلكتروني للمديرين
4. ✅ إرسال رسالة تأكيد البريد للمستخدم
5. ✅ التحقق من البريد الإلكتروني

استخدم **Mailtrap** للتطوير لأنه الأفضل والأسهل! 🎯