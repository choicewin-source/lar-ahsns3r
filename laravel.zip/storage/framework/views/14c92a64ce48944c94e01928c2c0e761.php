<a href="<?php echo e(route('products.show', $product->id)); ?>" 
   class="bg-white border border-gray-100 rounded-2xl p-4 shadow-sm hover:shadow-xl hover:-translate-y-1 hover:border-red-100 transition-all duration-300 flex flex-col h-full group">
    
    <!-- الصورة أو الأيقونة -->
    <div class="h-44 bg-gray-50 rounded-xl flex items-center justify-center text-6xl mb-4 group-hover:scale-105 transition-transform duration-500 relative overflow-hidden">
        <div class="absolute inset-0 bg-gradient-to-tr from-white/0 to-white/40 opacity-0 group-hover:opacity-100 transition-opacity"></div>
        <?php echo e($product->icon); ?>

    </div>

    <!-- التفاصيل -->
    <div class="flex-1">
        <h3 class="font-bold text-gray-900 text-lg mb-2 line-clamp-2 group-hover:text-red-600 transition-colors">
            <?php echo e($product->name); ?>

        </h3>
        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($showDetails): ?>
            <div class="flex items-center gap-2 text-xs text-gray-500 mb-3 bg-gray-50 w-fit px-2 py-1 rounded">
                <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path>
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path>
                </svg>
                <?php echo e($product->city); ?> | <?php echo e($product->shop_name); ?>

            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    <!-- السعر والزر -->
    <div class="mt-4 flex justify-between items-end border-t border-gray-50 pt-3">
        <div>
            <p class="text-[10px] text-gray-400 font-bold">السعر</p>
            <span class="text-2xl font-black text-red-600 leading-none">
                <?php echo e($product->formatted_price); ?>

            </span>
        </div>
        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($showDetails): ?>
            <!-- كود العرض التسلسلي -->
            <div class="text-left">
                <p class="text-[10px] text-gray-400 font-bold">كود العرض</p>
                <span class="text-xs font-bold text-blue-600 bg-blue-50 px-2 py-1 rounded">
                    <?php echo e($product->reference_code); ?>

                </span>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    <!-- نوع المصدر -->
    <div class="mt-3">
        <span class="<?php echo e($product->source_color); ?> text-white text-[10px] font-bold px-2 py-1 rounded shadow-sm">
            <?php echo e($product->source_text); ?>

        </span>
    </div>
</a><?php /**PATH /home/mohnd/projects/last/best-price/resources/views/components/product-card.blade.php ENDPATH**/ ?>