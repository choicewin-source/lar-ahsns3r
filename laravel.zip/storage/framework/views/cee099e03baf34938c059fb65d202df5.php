<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">معرض <?php echo e($shop->shop_name ?? $shop->name); ?></h2>
     <?php $__env->endSlot(); ?>

    <div class="py-8">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <!-- معلومات المتجر -->
            <div class="bg-gradient-to-r from-red-50 to-blue-50 p-6 rounded-2xl shadow-lg border border-red-100">
                <div class="flex flex-col md:flex-row items-center justify-between gap-4">
                    <div class="text-center md:text-right">
                        <div class="flex items-center gap-3 justify-center md:justify-start mb-2">
                            <div class="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center text-white font-bold text-xl">
                                <?php echo e(mb_substr($shop->shop_name ?? $shop->name, 0, 1)); ?>

                            </div>
                            <div>
                                <div class="text-sm text-gray-500 font-bold">🏪 معرض تجاري معتمد</div>
                                <div class="text-2xl font-black text-gray-800"><?php echo e($shop->shop_name ?? $shop->name); ?></div>
                            </div>
                        </div>
                        <div class="flex flex-col md:flex-row gap-4 text-sm text-gray-600">
                            <div class="flex items-center gap-1 justify-center md:justify-start">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                                <?php echo e($shop->shop_city ?? ''); ?>

                            </div>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($shop->shop_phone): ?>
                            <div class="flex items-center gap-1 justify-center md:justify-start">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path></svg>
                                <?php echo e($shop->shop_phone); ?>

                            </div>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>
                    <div class="text-center">
                        <div class="text-3xl font-black text-red-600"><?php echo e($products->total()); ?></div>
                        <div class="text-sm text-gray-500">منتج</div>
                    </div>
                </div>
            </div>

            <!-- المنتجات -->
            <div class="mt-8">
                <div class="flex justify-between items-center mb-6 border-b border-gray-200 pb-4">
                    <h3 class="text-xl font-black text-gray-800 flex items-center gap-3">
                        <span class="w-3 h-8 bg-red-600 rounded-full"></span>
                        جميع المنتجات (مرتبة حسب السعر)
                    </h3>
                    <div class="text-sm text-gray-500">
                        أقل سعر → أعلى سعر
                    </div>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <a href="<?php echo e(route('products.show', $product->id)); ?>" class="bg-white border border-gray-100 rounded-2xl p-4 shadow-sm hover:shadow-xl hover:-translate-y-1 hover:border-red-100 transition-all duration-300 flex flex-col h-full group">
                            
                            <!-- الصورة -->
                            <div class="h-44 bg-gray-50 rounded-xl flex items-center justify-center text-6xl mb-4 group-hover:scale-105 transition-transform duration-500 relative overflow-hidden">
                                <div class="absolute inset-0 bg-gradient-to-tr from-white/0 to-white/40 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Str::contains($product->category, 'جوال')): ?> 📱 
                                <?php elseif(Str::contains($product->category, 'كهرباء')): ?> 🔌
                                <?php elseif(Str::contains($product->category, 'أثاث')): ?> 🛋️
                                <?php elseif(Str::contains($product->category, 'شمس')): ?> ☀️
                                <?php elseif(Str::contains($product->category, 'خيم')): ?> ⛺
                                <?php elseif(Str::contains($product->category, 'سيار')): ?> 🚗
                                <?php elseif(Str::contains($product->category, 'عقار')): ?> 🏠
                                <?php else: ?> 📦 <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>

                            <!-- التفاصيل -->
                            <div class="flex-1">
                                <h3 class="font-bold text-gray-900 text-lg mb-2 line-clamp-2 group-hover:text-red-600 transition-colors">
                                    <?php echo e($product->name); ?>

                                </h3>
                                <div class="flex items-center gap-2 text-xs text-gray-500 mb-3 bg-gray-50 w-fit px-2 py-1 rounded">
                                    <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"></path></svg>
                                    <?php echo e($product->sub_category ?? $product->category); ?>

                                </div>
                            </div>

                            <!-- السعر وكود العرض -->
                            <div class="mt-4 flex justify-between items-end border-t border-gray-50 pt-3">
                                <div>
                                    <p class="text-[10px] text-gray-400 font-bold">السعر</p>
                                    <span class="text-2xl font-black text-red-600 leading-none">
                                        <?php echo e($product->formatted_price); ?>

                                    </span>
                                </div>
                                
                                <!-- كود العرض التسلسلي -->
                                <div class="text-left">
                                    <p class="text-[10px] text-gray-400 font-bold">كود العرض</p>
                                    <span class="text-xs font-bold text-blue-600 bg-blue-50 px-2 py-1 rounded">
                                        <?php echo e($product->reference_code); ?>

                                    </span>
                                </div>
                            </div>

                            <!-- التاريخ -->
                            <div class="mt-2 text-center">
                                <span class="text-xs text-gray-400 bg-gray-100 px-2 py-1 rounded">
                                    <?php echo e($product->created_at->format('Y-m-d')); ?>

                                </span>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-span-full py-16 text-center">
                            <div class="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center text-4xl mx-auto mb-4 grayscale opacity-50">📦</div>
                            <h3 class="text-lg font-bold text-gray-600">لا توجد منتجات حالياً</h3>
                            <p class="text-gray-400 text-sm mt-1">هذا المتجر لم يضف أي منتجات بعد</p>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
                
                <div class="mt-10">
                    <?php echo e($products->links()); ?>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /home/mohnd/projects/last/best-price/resources/views/shop/show.blade.php ENDPATH**/ ?>