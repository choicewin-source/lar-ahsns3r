<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" dir="rtl">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'أحسن سعر')); ?></title>

        <!-- 1. استدعاء خط Cairo من جوجل -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

        <!-- 2. تطبيق الخط على كل شيء -->
        <style>
            body, html, .font-sans, h1, h2, h3, h4, h5, h6, p, span, a, button, input, select {
                font-family: 'Cairo', sans-serif !important;
            }
            /* Hide elements with x-cloak until Alpine is ready */
            [x-cloak] { display: none !important; }
        </style>

        <!-- Livewire Styles -->
        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>


        <!-- Alpine.js from CDN - must load before Vite -->
        <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.14.1/dist/cdn.min.js"></script>

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="font-sans antialiased bg-gray-50 text-gray-800">
        <div class="min-h-screen flex flex-col justify-between">
            
            <!-- استدعاء الناف بار (الهيدر) -->
            <?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <!-- شريط الإعلانات المتحرك -->
            <?php if (isset($component)) { $__componentOriginale3c0bd2a5c09d06cfbb5bb20a41aebce = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale3c0bd2a5c09d06cfbb5bb20a41aebce = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.announcement-ticker','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('announcement-ticker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale3c0bd2a5c09d06cfbb5bb20a41aebce)): ?>
<?php $attributes = $__attributesOriginale3c0bd2a5c09d06cfbb5bb20a41aebce; ?>
<?php unset($__attributesOriginale3c0bd2a5c09d06cfbb5bb20a41aebce); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale3c0bd2a5c09d06cfbb5bb20a41aebce)): ?>
<?php $component = $__componentOriginale3c0bd2a5c09d06cfbb5bb20a41aebce; ?>
<?php unset($__componentOriginale3c0bd2a5c09d06cfbb5bb20a41aebce); ?>
<?php endif; ?>

            <!-- المحتوى المتغير -->
            <main class="flex-grow">
                <?php echo e($slot); ?>

            </main>

            <!-- فوتر بسيط وثابت -->
            <footer class="bg-white border-t border-gray-200 mt-auto py-8">
                <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
                    <div class="flex justify-center items-center gap-2 mb-2">
                        <span class="text-2xl font-black text-gray-800">أحسن</span>
                        <span class="text-2xl font-black text-red-600">سعر</span>
                    </div>
                    <p class="text-sm text-gray-500 font-bold mb-4">
                        دليلك الأول لمعرفة الأسعار في غزة 🇵🇸
                    </p>
                    <p class="text-xs text-gray-400">
                        جميع الحقوق محفوظة © <?php echo e(date('Y')); ?>

                    </p>
                </div>
            </footer>

        </div>

        <!-- Livewire Scripts -->
        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

    </body>
</html><?php /**PATH /home/mohnd/projects/last/best-price/resources/views/layouts/app.blade.php ENDPATH**/ ?>