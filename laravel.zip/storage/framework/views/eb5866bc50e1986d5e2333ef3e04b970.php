<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12" dir="rtl">
        <div class="max-w-xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-yellow-50 border-r-4 border-yellow-400 p-4 mb-4 rounded shadow-sm">
                <div class="flex">
                    <div class="mr-3">
                        <h3 class="text-sm font-medium text-yellow-800">وضع التعديل</h3>
                        <div class="mt-2 text-sm text-yellow-700">
                            أنت الآن تقوم بتعديل بيانات منتج باستخدام الرابط الخاص بك.
                        </div>
                    </div>
                </div>
            </div>

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                <h2 class="text-xl font-bold mb-6 text-gray-800">تعديل: <?php echo e($product->name); ?></h2>

                <form action="<?php echo e(route('products.update', $product->edit_token)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <!-- السعر -->
                    <div class="mb-4">
                        <label class="block text-gray-700 text-sm font-bold mb-2">تحديث السعر</label>
                        <input type="number" step="0.01" name="price" value="<?php echo e($product->price); ?>"
                            class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 border-green-200 bg-green-50 font-bold text-lg">
                    </div>

                    <!-- المحل -->
                    <div class="mb-4">
                        <label class="block text-gray-700 text-sm font-bold mb-2">اسم المحل</label>
                        <input type="text" name="shop_name" value="<?php echo e($product->shop_name); ?>"
                            class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>

                    <!-- تفاصيل العنوان -->
                    <div class="mb-6">
                        <label class="block text-gray-700 text-sm font-bold mb-2">تحديث العنوان</label>
                        <textarea name="address_details" rows="2"
                            class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"><?php echo e($product->address_details); ?></textarea>
                    </div>

                    <!-- زر الحفظ -->
                    <button type="submit" class="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-4 rounded-lg shadow-md transition">
                        حفظ التعديلات ✅
                    </button>
                    
                    <a href="<?php echo e(route('home')); ?>" class="block text-center mt-4 text-gray-500 text-sm hover:underline">إلغاء</a>
                </form>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /home/mohnd/projects/last/best-price/resources/views/products/edit.blade.php ENDPATH**/ ?>