<?php

namespace App\Livewire;

use App\Models\Product;
use App\Models\Category;
use App\Models\Ad;
use Livewire\Component;
use Livewire\WithPagination;
use Livewire\Attributes\Layout;
use Illuminate\Support\Facades\Cache;

#[Layout('layouts.app')]
class HomePage extends Component
{
    use WithPagination;

    public $search = ''; 
    public $selectedCategory = ''; 
    public $selectedCity = ''; // تم تصحيح الاسم
    public $selectedShop = ''; // جديد: لفلترة منتجات محل معين
    public $sub_category = ''; // القسم الفرعي المحدد
    public $condition = ''; // حالة المنتج: جديد أو مستعمل
    public $tickerText = ''; // شريط الإعلانات المتحرك

    // سيتم جلب القائمة من جدول الفئات
    public $categoriesList = [];

    public $cities = ['شمال غزة', 'مدينة غزة', 'المنطقة الوسطى', 'خانيونس', 'رفح'];
    public $ads = [];

    public function selectCity($city)
    {
        $this->selectedCity = $city === $this->selectedCity ? '' : $city;
        $this->resetPage(); 
    }

    public function selectCategory($category)
    {
        $this->selectedCategory = $category === $this->selectedCategory ? '' : $category;
        $this->selectedShop = ''; // تصفير المحل عند اختيار قسم
        $this->resetPage(); 
    }

    public function mount()
    {
        // استقبال اسم المحل من الرابط إذا وجد (shop_profile)
        if(request()->has('shop')) {
            $this->selectedShop = request('shop');
        }

        // جلب الفئات من DB مع الأقسام الفرعية - مع Caching
        // تم تحديث المنطق لدمج الأيقونات والأقسام الفرعية المطلوبة حسب المحادثة
        $this->categoriesList = Cache::remember('categories_list_v2', 3600, function() {
            // خريطة الأيقونات والأقسام الفرعية حسب طلب العميل
            $customMap = [
                'أجهزة كهربائية وطاقة' => ['icon' => '🔌☀️', 'subs' => []],
                'أثاث ومفروشات وخيام' => ['icon' => '🛋️⛺', 'subs' => []],
                'سيارات ودراجات' => ['icon' => '🚗🚲', 'subs' => []],
                'جوالات وإلكترونيات' => ['icon' => '📱', 'subs' => []],
                'مطاعم' => ['icon' => '🍽️', 'subs' => []],
                'عقارات' => ['icon' => '🏠', 'subs' => []],
                'ملابس' => ['icon' => '👕', 'subs' => ['ملابس رجالية', 'ملابس نسائية', 'ملابس أطفال', 'أحذية وإكسسوارات']],
                'خدمات إلكترونية' => ['icon' => '🧾💻', 'subs' => ['استضافة ومواقع', 'تصميم وبرمجة', 'تسويق إلكتروني', 'خدمات دفع', 'صيانة إلكترونية']],
                'مواد غذائية وسوبر ماركت' => ['icon' => '🛒', 'subs' => ['خضار وفواكه', 'ألبان', 'لحوم ودواجن', 'مواد معلبة', 'مشروبات وحلويات']],
                'مواد بناء ولوازم منزلية' => ['icon' => '🧰', 'subs' => ['مواد بناء أساسية', 'أدوات كهربائية وسباكة', 'دهانات', 'أثاث منزلي', 'أدوات يدوية']],
                'صيدليات ومستلزمات طبية' => ['icon' => '🩺', 'subs' => ['أدوية', 'مستلزمات طبية', 'مكملات غذائية', 'مستلزمات أطفال']],
                'خدمات عامة' => ['icon' => '🛠️', 'subs' => ['صيانة كهرباء وسباكة', 'توصيل ونقل', 'تنظيف', 'تصليح أجهزة']],
                'ترفيه وألعاب ورياضة' => ['icon' => '🎮⚽️', 'subs' => ['ألعاب فيديو', 'ألعاب أطفال', 'معدات رياضية', 'أنشطة ترفيهية']],
                'زراعة وحيوانات' => ['icon' => '🐔🐄', 'subs' => ['حيوانات أليفة', 'أعلاف', 'أدوات زراعة', 'معدات ري']],
                'أخرى' => ['icon' => '📦', 'subs' => []],
            ];

            return Category::orderBy('id')->get()->map(function($c) use ($customMap) {
                // البحث عن الإعدادات المخصصة بناءً على الاسم
                $custom = $customMap[$c->name] ?? null;
                
                return [
                    'name' => $c->name,
                    // استخدام الأيقونة المخصصة إذا وجدت، وإلا استخدام الموجودة في القاعدة
                    'icon' => $custom['icon'] ?? ($c->icon ?? '📦'),
                    'slug' => $c->slug,
                    // دمج الأقسام الفرعية من القاعدة مع القائمة المخصصة
                    'subs' => array_unique(array_merge($c->subs ?? [], $custom['subs'] ?? [])),
                ];
            })->toArray();
        });

        // جلب الإعلانات المفعلّة - مع Caching
        $this->ads = Cache::remember('active_ads', 300, function() {
            return Ad::where('is_active', true)->orderBy('order')->get()->groupBy('order')->toArray();
        });

        // إعداد نص الشريط المتحرك (الآن كـ array)
        $this->tickerText = [
            '📢 مرحبًا بكم في منصة "أحسن سعر" - دليلك الأول للأسعار في غزة',
            '🔥 الأسعار الأرخص تظهر أولاً دائماً!',
            '✅ يمكن لأصحاب المحلات إضافة بضائعهم وإنشاء متجر خاص مجاناً',
            '⚠️ الإبلاغ عن الأسعار الوهمية يساعدنا في الحفاظ على المصداقية',
            '📞 لأي ملاحظة تواصل معنا على تليجرام: @shady2013',
            '✨ اكتشف موقع أحسن سعر - قارن، شارك، ووفّر!',
        ];
    }

    public function render()
    {
        // جلب جميع المنتجات المعتمدة مع الفلاتر
        $query = Product::select('id', 'name', 'price', 'image_path', 'city', 'shop_name', 'created_at', 'category', 'sub_category', 'reference_code', 'condition', 'added_by', 'user_id')
            ->with('user:id,name,shop_name,is_approved')
            ->where('is_approved', true);

        // فلترة حسب القسم الرئيسي
        if ($this->selectedCategory) {
            $query->where('category', $this->selectedCategory);
        }

        // فلترة حسب المدينة
        if ($this->selectedCity) {
            $query->where('city', $this->selectedCity);
        }

        // فلترة حسب اسم المحل
        if ($this->selectedShop) {
            $query->where('shop_name', $this->selectedShop);
        }

        // البحث في اسم المنتج
        if ($this->search) {
            $query->where('name', 'like', '%' . $this->search . '%');
        }

        // فلترة حسب الحالة (جديد / مستعمل)
        if ($this->condition) {
            $query->where('condition', $this->condition);
        }

        // جلب كل المنتجات مع الفلاتر - مرتبة من الأحدث للأقدم
        $allProducts = $query->orderBy('created_at', 'desc')->get();

        // تجميع المنتجات حسب النظام الهرمي: Category > Sub_Category > Name
        // ثم أخذ أفضل سعر (الأقل) من كل موديل على حدة
        $bestPriceProducts = $allProducts
            ->groupBy(function($product) {
                // المفتاح الفريد: القسم + القسم الفرعي + الاسم (الموديل)
                // تمت إزالة condition لضمان المقارنة بين نفس الموديل بغض النظر عن الحالة
                return $product->category . '|' . 
                       ($product->sub_category ?? 'N/A') . '|' . 
                       trim($product->name);
            })
            ->map(function($group) {
                // من كل مجموعة، نأخذ المنتج ذو أقل سعر
                // ولكن نحفظ أيضاً تاريخ أحدث منتج في المجموعة
                $cheapest = $group->sortBy('price')->first();
                $cheapest->latest_in_group = $group->max('created_at');
                return $cheapest;
            })
            ->values()
            ->sortByDesc('latest_in_group') // ترتيب حسب أحدث منتج في كل مجموعة
            ->values();

        // تحويل النتيجة إلى Paginator
        $perPage = 15;
        $currentPage = \Illuminate\Pagination\Paginator::resolveCurrentPage('page');
        $currentItems = $bestPriceProducts->slice(($currentPage - 1) * $perPage, $perPage)->values();
        
        $products = new \Illuminate\Pagination\LengthAwarePaginator(
            $currentItems,
            $bestPriceProducts->count(),
            $perPage,
            $currentPage,
            ['path' => \Illuminate\Pagination\Paginator::resolveCurrentPath()]
        );

        return view('livewire.home-page', [
            'products' => $products,
            'categoriesList' => $this->categoriesList,
            'ads' => $this->ads,
            'tickerText' => $this->tickerText,
        ]);
    }
}
